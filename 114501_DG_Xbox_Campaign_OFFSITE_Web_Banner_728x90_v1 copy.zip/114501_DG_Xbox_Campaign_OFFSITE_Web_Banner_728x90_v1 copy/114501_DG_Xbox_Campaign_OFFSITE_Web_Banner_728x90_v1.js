(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"114501_DG_Xbox_Campaign_OFFSITE_Web_Banner_728x90_v1_atlas_1", frames: [[1091,0,1088,1538],[2181,0,1088,1538],[0,0,1089,1542]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Xbox_Game_Pass_Ultimate_1mo_M6NS_14_99_043021_RGB = function() {
	this.initialize(ss["114501_DG_Xbox_Campaign_OFFSITE_Web_Banner_728x90_v1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Xbox_Game_Pass_Ultimate_3mo_M6NS_44_99_043021_RGB = function() {
	this.initialize(ss["114501_DG_Xbox_Campaign_OFFSITE_Web_Banner_728x90_v1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Xbox_Gift_Card_M6NS_50_052119_RGB = function() {
	this.initialize(ss["114501_DG_Xbox_Campaign_OFFSITE_Web_Banner_728x90_v1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Vertical_Stretch_Shape_Black_RGBai = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Vertical_Stretch_Shape_Black_RGB_ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A+9dnQj5AAirgXQisgWAAggIABgGQGguGABuOQgBuNmguHIgBgFQAAggCsgWQCrgXD5AAMA96AAAQD6AACrAXQCsAWAAAgIgBAFQmhOJAAOLQAAONGhOHIABAGQAAAgisAWQirAXj6AAg");
	this.shape.setTransform(257.4,189.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,514.8,379);


(lib.type = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOAjIAAgLQAHAEAFAAQADAAACgCQACgCAAgEQAAgGgHgKQgHgHgDgFQgDgFAAgGQAAgIAFgFQAFgFAHAAQAGAAAFACIAAALQgGgDgEAAQgDAAgCACQgCACAAAEQAAADACACIAFAJQAIAIACAFQADAGAAAGQAAAIgFAFQgFAFgHAAQgHAAgGgDg");
	this.shape.setTransform(168.275,53.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAHAmIgJgcIgCAAIgDAAIAAAcIgKAAIAAhLIAMAAQAKAAAGAGQAGAGAAAMIAAAAQAAAOgKAGIALAfgAgHABIACAAQALAAAAgNIAAgBQAAgOgLAAIgCAAg");
	this.shape_1.setTransform(164.525,53.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgNAmIAAhLIAbAAIAAAKIgRAAIAAAXIAPAAIAAAJIgPAAIAAAXIARAAIAAAKg");
	this.shape_2.setTransform(160.625,53.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAJAmIgQgvIAAAvIgLAAIAAhLIAKAAIAQAuIAAguIAKAAIAABLg");
	this.shape_3.setTransform(156.5,53.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAJAmIgJgzIgHAzIgLAAIgMhLIALAAIAHAzIAIgzIAJAAIAIAzIAIgzIAKAAIgLBLg");
	this.shape_4.setTransform(150.95,53.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgNAeQgGgKABgSIAAgDQgBgSAGgKQAFgJAIAAQAJAAAFAJQAFAKABASIAAADQgBASgFAKQgFAJgJAAQgIAAgFgJgAgHgBIAAADQAAAbAHAAQAJAAAAgbIAAgDQAAgbgJAAQgHAAAAAbg");
	this.shape_5.setTransform(145.55,53.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgNAmIAAhLIAbAAIAAAKIgRAAIAAAXIAPAAIAAAJIgPAAIAAAXIARAAIAAAKg");
	this.shape_6.setTransform(139.925,53.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgFAmIgOhLIALAAIAIA2IAJg2IALAAIgPBLg");
	this.shape_7.setTransform(136.025,53.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgEAmIAAhLIAJAAIAABLg");
	this.shape_8.setTransform(132.975,53.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgEAmIAAhBIgLAAIAAgKIAeAAIAAAKIgKAAIAABBg");
	this.shape_9.setTransform(130.25,53.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgIAdQgGgJAAgTIAAgBQAAgTAGgKQAGgIAIAAQAFAAAEABIAAALQgEgCgEAAQgKAAAAAbIAAABQAAAbAKAAQAEAAAEgCIAAAKQgEACgFAAQgJAAgFgJg");
	this.shape_10.setTransform(126.8,53.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgNAmIAAhLIAbAAIAAAKIgRAAIAAAXIAPAAIAAAJIgPAAIAAAXIARAAIAAAKg");
	this.shape_11.setTransform(123.325,53.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgQAmIAAhLIALAAQAKAAAGAGQAGAHAAAMQAAAMgGAGQgGAGgJABIgCAAIAAAZgAgGADIACAAQAEAAADgDQAEgEAAgHIAAgBQAAgPgLAAIgCAAg");
	this.shape_12.setTransform(119.575,53.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgOAjIAAgLQAHAEAFAAQADAAACgCQACgCAAgEQAAgGgHgKQgHgHgDgFQgDgFAAgGQAAgIAFgFQAFgFAHAAQAGAAAFACIAAALQgGgDgEAAQgDAAgCACQgCACAAAEQAAADACACIAFAJQAIAIACAFQADAGAAAGQAAAIgFAFQgFAFgHAAQgHAAgGgDg");
	this.shape_13.setTransform(115.625,53.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgNAmIAAhLIAbAAIAAAKIgRAAIAAAXIAPAAIAAAJIgPAAIAAAXIARAAIAAAKg");
	this.shape_14.setTransform(112.225,53.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAHAmIgJgcIgCAAIgDAAIAAAcIgKAAIAAhLIAMAAQAKAAAGAGQAGAGAAAMIAAAAQAAAOgKAGIALAfgAgHABIACAAQALAAAAgNIAAgBQAAgOgLAAIgCAAg");
	this.shape_15.setTransform(108.375,53.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAHAmIgJgcIgCAAIgDAAIAAAcIgKAAIAAhLIAMAAQAKAAAGAGQAGAGAAAMIAAAAQAAAOgKAGIALAfgAgHABIACAAQALAAAAgNIAAgBQAAgOgLAAIgCAAg");
	this.shape_16.setTransform(102.425,53.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgEAmIAAhLIAJAAIAABLg");
	this.shape_17.setTransform(99.175,53.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgNAmIAAhLIAbAAIAAAKIgRAAIAAAXIAPAAIAAAJIgPAAIAAAXIARAAIAAAKg");
	this.shape_18.setTransform(96.475,53.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAHAmIAAghIgOAAIAAAhIgKAAIAAhLIAKAAIAAAhIAOAAIAAghIALAAIAABLg");
	this.shape_19.setTransform(92.375,53.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgEAmIAAhBIgKAAIAAgKIAdAAIAAAKIgJAAIAABBg");
	this.shape_20.setTransform(88.45,53.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgMAmIAAhLIAZAAIAAAKIgPAAIAAAXIAOAAIAAAJIgOAAIAAAhg");
	this.shape_21.setTransform(83.425,53.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgNAeQgFgKgBgSIAAgDQABgSAFgKQAFgJAIAAQAJAAAFAJQAGAKgBASIAAADQABASgGAKQgFAJgJAAQgIAAgFgJgAgIgBIAAADQAAAbAIAAQAIAAAAgbIAAgDQAAgbgIAAQgIAAAAAbg");
	this.shape_22.setTransform(79.45,53.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgEAmIAAgfIgPgsIALAAIAIAfIAJgfIALAAIgOAsIAAAfg");
	this.shape_23.setTransform(73.5,53.375);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgEAmIAAhBIgLAAIAAgKIAfAAIAAAKIgKAAIAABBg");
	this.shape_24.setTransform(69.8,53.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAHAmIgJgcIgCAAIgDAAIAAAcIgKAAIAAhLIAMAAQAKAAAGAGQAGAGAAAMIAAAAQAAAOgKAGIALAfgAgHABIACAAQALAAAAgNIAAgBQAAgOgLAAIgCAAg");
	this.shape_25.setTransform(66.175,53.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgNAmIAAhLIAbAAIAAAKIgRAAIAAAXIAPAAIAAAJIgPAAIAAAXIARAAIAAAKg");
	this.shape_26.setTransform(62.225,53.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgQAmIAAhLIALAAQAKAAAGAGQAGAHAAAMQAAAMgGAGQgGAGgJABIgCAAIAAAZgAgGADIACAAQAEAAADgDQAEgEAAgHIAAgBQAAgPgLAAIgCAAg");
	this.shape_27.setTransform(58.475,53.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgNAeQgFgKAAgSIAAgDQAAgSAFgKQAFgJAIAAQAJAAAFAJQAGAKgBASIAAADQABASgGAKQgFAJgJAAQgIAAgFgJgAgIgBIAAADQAAAbAIAAQAIAAAAgbIAAgDQAAgbgIAAQgIAAAAAbg");
	this.shape_28.setTransform(54.05,53.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAHAmIgJgcIgCAAIgDAAIAAAcIgKAAIAAhLIAMAAQAKAAAGAGQAGAGAAAMIAAAAQAAAOgKAGIALAfgAgHABIACAAQALAAAAgNIAAgBQAAgOgLAAIgCAAg");
	this.shape_29.setTransform(49.875,53.375);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgQAmIAAhLIALAAQAKAAAGAGQAGAHAAAMQAAAMgGAGQgGAGgJABIgCAAIAAAZgAgGADIACAAQAEAAADgDQAEgEAAgHIAAgBQAAgPgLAAIgCAAg");
	this.shape_30.setTransform(45.675,53.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgNAmIAAhLIAbAAIAAAKIgRAAIAAAXIAPAAIAAAJIgPAAIAAAXIARAAIAAAKg");
	this.shape_31.setTransform(40.125,53.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAHAmIgJgcIgCAAIgDAAIAAAcIgKAAIAAhLIAMAAQAKAAAGAGQAGAGAAAMIAAAAQAAAOgKAGIALAfgAgHABIACAAQALAAAAgNIAAgBQAAgOgLAAIgCAAg");
	this.shape_32.setTransform(36.325,53.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAKAmIgDgRIgNAAIgDARIgLAAIAPhLIALAAIAPBLgAAFAMIgFgeIgFAeIAKAAg");
	this.shape_33.setTransform(31.875,53.35);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgOAjIAAgLQAHAEAFAAQADAAACgCQACgCAAgEQAAgGgHgKQgHgHgDgFQgDgFAAgGQAAgIAFgFQAFgFAHAAQAGAAAFACIAAALQgGgDgEAAQgDAAgCACQgCACAAAEQAAADACACIAFAJQAIAIACAFQADAGAAAGQAAAIgFAFQgFAFgHAAQgHAAgGgDg");
	this.shape_34.setTransform(26.225,53.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AAHAmIgKgfIgEAJIAAAWIgLAAIAAhLIALAAIAAAkIANgkIAMAAIgOAhIAOAqg");
	this.shape_35.setTransform(22.55,53.375);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAHAmIgJgcIgCAAIgDAAIAAAcIgKAAIAAhLIAMAAQAKAAAGAGQAGAGAAAMIAAAAQAAAOgKAGIALAfgAgHABIACAAQALAAAAgNIAAgBQAAgOgLAAIgCAAg");
	this.shape_36.setTransform(18.275,53.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AAKAmIgDgRIgNAAIgDARIgLAAIAPhLIALAAIAPBLgAAFAMIgFgeIgFAeIAKAAg");
	this.shape_37.setTransform(13.875,53.35);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AALAmIAAgzIgLAhIAAAAIgKghIAAAzIgKAAIAAhLIALAAIAJAhIAKghIALAAIAABLg");
	this.shape_38.setTransform(9.05,53.375);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgNAmIAAhLIAbAAIAAAKIgRAAIAAAXIAPAAIAAAJIgPAAIAAAXIARAAIAAAKg");
	this.shape_39.setTransform(4.825,53.375);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgRAmIAAhLIALAAQALAAAGAJQAIAKAAASIAAABQAAASgIAKQgGAJgLAAgAgHAcIACAAQANAAAAgbIAAgBQAAgOgFgHQgDgGgFAAIgCAAg");
	this.shape_40.setTransform(0.85,53.375);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAKAmIgDgRIgNAAIgDARIgLAAIAPhLIALAAIAPBLgAAFAMIgFgeIgFAeIAKAAg");
	this.shape_41.setTransform(-3.625,53.35);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AAHAmIgJgcIgCAAIgDAAIAAAcIgKAAIAAhLIAMAAQAKAAAGAGQAGAGAAAMIAAAAQAAAOgKAGIALAfgAgHABIACAAQALAAAAgNIAAgBQAAgOgLAAIgCAAg");
	this.shape_42.setTransform(-7.725,53.375);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgEAmIAAhBIgKAAIAAgKIAdAAIAAAKIgKAAIAABBg");
	this.shape_43.setTransform(-11.7,53.375);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgMAmIAAhLIALAAIAABBIAOAAIAAAKg");
	this.shape_44.setTransform(-16.5,53.375);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgMAmIAAhLIALAAIAABBIAOAAIAAAKg");
	this.shape_45.setTransform(-19.65,53.375);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AAKAmIgDgRIgNAAIgDARIgLAAIAPhLIALAAIAPBLgAAFAMIgFgeIgFAeIAKAAg");
	this.shape_46.setTransform(-23.525,53.35);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AAAAxIAAhRIgMAFIgBgOIARgHIAKAAIAABhg");
	this.shape_47.setTransform(159.475,36.675);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgZAoIAGgMQAJAHAHAAQAGAAAEgEQAFgEAAgIIAAAAQgBgIgFgEQgGgEgJAAIgCAAIgBgJIAUgcIgeAAIAAgOIAvAAIAAAMIgVAdQAJACAHAFQAGAHABALIAAABQAAAOgJAIQgIAIgMAAQgOAAgJgJg");
	this.shape_48.setTransform(154.9,36.775);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgaA9IAph5IAMAAIgpB5g");
	this.shape_49.setTransform(149.575,36.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgZAxIAAgMIAZgjIAIgNQADgFAAgFQAAgGgEgDQgDgEgEAAQgJAAgHAKIgJgKQAKgOAPAAQAMAAAHAHQAHAHAAALIAAABQAAAIgDAHQgDAGgIAKIgSAaIAgAAIAAAOg");
	this.shape_50.setTransform(144.225,36.625);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AAAAxIAAhRIgMAFIgBgOIARgHIAKAAIAABhg");
	this.shape_51.setTransform(139.025,36.675);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgJAMQALgCgCgKIgGAAIAAgSIAQAAIAAAPQAAATgSADg");
	this.shape_52.setTransform(133.525,41.675);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgGAxIAAhTIgUAAIAAgNIA1AAIAAANIgTAAIAABTg");
	this.shape_53.setTransform(129.35,36.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AAUAxIgGgXIgcAAIgGAXIgOAAIAbhhIAOAAIAcBhgAAKANIgKgmIgKAmIAUAAg");
	this.shape_54.setTransform(122.875,36.675);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgcAlIAJgMQALALAIAAQAGAAAEgEQADgEAAgEIAAgBQAAgEgCgEQgEgEgIgFQgMgGgFgGQgGgHABgJQAAgMAHgHQAIgHAMAAQAOAAALAKIgJALQgJgHgIgBQgEAAgEAEQgEACAAAGQABAEADADQADAFAJAGQAMAFAEAHQAFAGABAKQgBAMgHAHQgJAIgMAAQgPAAgNgNg");
	this.shape_55.setTransform(116.1,36.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgRAHIAAgNIAjAAIAAANg");
	this.shape_56.setTransform(108.65,37.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgaAoIAIgMQAIAHAIAAQAFAAAFgFQAEgFAAgIIAAAAQAAgIgFgEQgEgFgGAAQgFAAgGADIgIgEIACgvIArAAIAAAOIgeAAIgCAXIAJgBQALAAAIAHQAIAHAAAOIAAABQAAAOgJAJQgIAJgMAAQgOAAgKgJg");
	this.shape_57.setTransform(101.025,36.775);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgZAxIAAgMIAZgjIAIgNQADgFAAgFQAAgGgEgDQgDgEgEAAQgJAAgHAKIgJgKQAKgOAPAAQAMAAAHAHQAHAHAAALIAAABQAAAIgDAHQgDAGgIAKIgSAaIAgAAIAAAOg");
	this.shape_58.setTransform(95.175,36.625);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgaA9IAph5IAMAAIgpB5g");
	this.shape_59.setTransform(89.675,36.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgZAxIAAgMIAZgjIAIgNQADgFAAgFQAAgGgEgDQgDgEgEAAQgJAAgHAKIgJgKQAKgOAPAAQAMAAAHAHQAHAHAAALIAAABQAAAIgDAHQgDAGgIAKIgSAaIAgAAIAAAOg");
	this.shape_60.setTransform(84.325,36.625);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AAAAxIAAhRIgMAFIgBgOIARgHIAKAAIAABhg");
	this.shape_61.setTransform(79.125,36.675);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgJAMQALgCgCgKIgGAAIAAgSIAQAAIAAAPQAAATgSADg");
	this.shape_62.setTransform(73.625,41.675);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AARAxIggg/IAAA/IgOAAIAAhgIAOAAIAfA9IAAg9IAOAAIAABgg");
	this.shape_63.setTransform(68.625,36.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgVApQgIgJAAgRIAAg/IAPAAIAABAQAAATAOAAQAPAAAAgTIAAhAIAPAAIAAA/QAAARgIAJQgIAIgOAAQgNAAgIgIg");
	this.shape_64.setTransform(61.275,36.775);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgcAlIAJgMQALALAIAAQAGAAADgEQAFgEAAgEIAAgBQAAgEgEgEQgDgEgHgFQgNgGgFgGQgGgHAAgJQAAgMAIgHQAIgHAMAAQAOAAAKAKIgJALQgIgHgJgBQgEAAgDAEQgDACgBAGQAAAEADADQAEAFAJAGQAMAFAFAHQAEAGAAAKQAAAMgIAHQgIAIgMAAQgPAAgNgNg");
	this.shape_65.setTransform(54.6,36.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgHAlIAAgSIAPAAIAAASgAgHgSIAAgSIAPAAIAAASg");
	this.shape_66.setTransform(47.925,37.875);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgeAxIAAhgIAWAAQASAAAKAMQALANAAAWIAAABQAAAWgLANQgKANgSAAgAgPAjIAHAAQALAAAGgJQAHgIgBgRIAAgBQAAgQgGgKQgHgIgKAAIgHAAg");
	this.shape_67.setTransform(42.95,36.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgHAxIAAhgIAPAAIAABgg");
	this.shape_68.setTransform(37.65,36.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgWAxIAAhgIAPAAIAABRIAeAAIAAAPg");
	this.shape_69.setTransform(33.7,36.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AAUAxIgGgXIgcAAIgGAXIgOAAIAbhhIAOAAIAcBhgAAKANIgKgmIgKAmIAUAAg");
	this.shape_70.setTransform(27.075,36.675);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgGAxIgahhIAPAAIARBHIAShHIAPAAIgaBhg");
	this.shape_71.setTransform(20.675,36.725);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AANAxIgQgjIgCAAIgJAAIAAAjIgPAAIAAhgIAaAAQAOAAAJAIQAHAIAAAOIAAAAQAAATgQAIIATAngAgOAAIAJAAQASABAAgSQAAgRgSAAIgJAAg");
	this.shape_72.setTransform(11.725,36.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgXAxIAAhgIAvAAIAAANIghAAIAAAcIAdAAIAAAMIgdAAIAAAcIAhAAIAAAPg");
	this.shape_73.setTransform(5.15,36.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgXAxIAAhgIAvAAIAAANIggAAIAAAdIAcAAIAAAMIgcAAIAAAqg");
	this.shape_74.setTransform(-0.65,36.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgXAxIAAhgIAvAAIAAANIggAAIAAAdIAcAAIAAAMIgcAAIAAAqg");
	this.shape_75.setTransform(-6.4,36.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgYAlQgJgNAAgXIAAgBQAAgWAJgOQAKgNAOAAQAPAAAKANQAJANAAAWIAAACQAAAXgJANQgKANgPAAQgOAAgKgNgAgNgaQgFAJAAARIAAABQAAAQAFAKQAGAJAHAAQAIAAAGgJQAFgJAAgRIAAgBQAAgRgFgJQgGgJgIAAQgIAAgFAJg");
	this.shape_76.setTransform(-13.375,36.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgKAMIAAgXIAVAAIAAAXg");
	this.shape_77.setTransform(176.875,25.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AglAyIAMgQQAOAOALAAQAIAAAFgFQAFgEAAgIQAAgGgEgEQgEgFgLgHQgRgJgHgJQgHgJAAgMQAAgQAKgKQALgKAQAAQATAAAOAPIgMAPQgLgLgLAAQgHAAgEAEQgFAEAAAHQAAAGAEAFQAFAFANAIQAPAJAHAIQAGAJAAAMQAAAQgLALQgLAKgQAAQgUAAgRgRg");
	this.shape_78.setTransform(170.475,20.075);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgpBBIAAiBIAeAAQAYAAAOARQAPARAAAeIAAABQAAAegPARQgOARgYAAgAgUAvIAJAAQAOAAAJgLQAJgMAAgXIAAgBQAAgWgJgMQgJgMgOAAIgJAAg");
	this.shape_79.setTransform(161.575,20.075);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AASBBIgWgvIgCAAIgNAAIAAAvIgUAAIAAiBIAjAAQATAAAMALQAKALAAATIAAABQAAAZgWAKIAZA0gAgTAAIAMAAQAYAAAAgWQAAgYgXAAIgNAAg");
	this.shape_80.setTransform(151.875,20.075);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AAbBCIgIgfIgmAAIgIAfIgUAAIAmiDIAUAAIAlCDgAAOARIgOgzIgNAzIAbAAg");
	this.shape_81.setTransform(141.75,20.05);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgZAyQgNgRAAggIAAgBQAAgfAOgSQANgRAUAAQARAAAMAMIgLAQQgJgIgJAAQgLAAgHAMQgJANAAAVIAAAAQAAAXAJANQAHAMAKAAQALAAAJgKIALAQQgOANgRAAQgVAAgMgRg");
	this.shape_82.setTransform(132.35,20.075);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgJBBIAAhuIgaAAIAAgTIBHAAIAAATIgaAAIAABug");
	this.shape_83.setTransform(120.125,20.075);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AggBBIAAiBIBAAAIAAASIgrAAIAAAnIAmAAIAAARIgmAAIAAA3g");
	this.shape_84.setTransform(112.35,20.075);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgJBBIAAiBIATAAIAACBg");
	this.shape_85.setTransform(105.85,20.075);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgbAyQgOgSAAgfIAAgBQAAgeAOgSQAOgSAWAAQASAAAOAMIgLAQQgJgJgLAAQgNAAgJANQgJAMAAAWIAAABQAAAXAJANQAJALANAAQAIAAAFgDIAAgiIgUAAIAAgRIAnAAIAAA+QgRALgRAAQgVAAgOgRg");
	this.shape_86.setTransform(98.55,20.075);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgJBBIAAhuIgaAAIAAgTIBHAAIAAATIgaAAIAABug");
	this.shape_87.setTransform(86.025,20.075);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgZAyQgNgRAAggIAAgBQAAgfAOgSQANgRAUAAQARAAANAMIgMAQQgJgIgJAAQgLAAgIAMQgIANAAAVIAAAAQAAAXAIANQAIAMAKAAQAKAAAKgKIALAQQgOANgSAAQgTAAgNgRg");
	this.shape_88.setTransform(77.65,20.075);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AggBBIAAiBIBBAAIAAASIgtAAIAAAlIAoAAIAAASIgoAAIAAAmIAtAAIAAASg");
	this.shape_89.setTransform(69.025,20.075);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgeBBIAAiBIAVAAIAABvIAoAAIAAASg");
	this.shape_90.setTransform(61.15,20.075);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AggBBIAAiBIBBAAIAAASIgtAAIAAAlIAoAAIAAASIgoAAIAAAmIAtAAIAAASg");
	this.shape_91.setTransform(52.975,20.075);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AglAyIAMgQQAOAOALAAQAIAAAFgFQAFgEAAgIQAAgGgEgEQgEgFgLgHQgRgJgHgJQgHgJAAgMQAAgQAKgKQALgKAQAAQATAAAOAPIgMAPQgLgLgLAAQgHAAgEAEQgFAEAAAHQAAAGAEAFQAFAFANAIQAPAJAHAIQAGAJAAAMQAAAQgLALQgLAKgQAAQgUAAgRgRg");
	this.shape_92.setTransform(44.175,20.075);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AggBBIAAiBIBBAAIAAASIgtAAIAAAlIAoAAIAAASIgoAAIAAAmIAtAAIAAASg");
	this.shape_93.setTransform(32.725,20.075);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AglAyIAMgQQAOAOALAAQAIAAAFgFQAFgEAAgIQAAgGgEgEQgEgFgLgHQgRgJgHgJQgHgJAAgMQAAgQAKgKQALgKAQAAQATAAAOAPIgMAPQgLgLgLAAQgHAAgEAEQgFAEAAAHQAAAGAEAFQAFAFANAIQAPAJAHAIQAGAJAAAMQAAAQgLALQgLAKgQAAQgUAAgRgRg");
	this.shape_94.setTransform(23.975,20.075);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AggBBIAAiBIBBAAIAAASIgtAAIAAAlIAoAAIAAASIgoAAIAAAmIAtAAIAAASg");
	this.shape_95.setTransform(16.025,20.075);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AATBBIAAg4IglAAIAAA4IgUAAIAAiBIAUAAIAAA3IAlAAIAAg3IAVAAIAACBg");
	this.shape_96.setTransform(6.55,20.075);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgJBBIAAhuIgaAAIAAgTIBHAAIAAATIgaAAIAABug");
	this.shape_97.setTransform(-2.525,20.075);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AAXBBIgrhVIAABVIgUAAIAAiBIATAAIArBSIAAhSIATAAIAACBg");
	this.shape_98.setTransform(-15.3,20.075);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AghAyQgMgSAAgeIAAgDQAAgeANgSQANgRATAAQAVAAAMARQANASAAAeIAAADQAAAegNASQgMARgVAAQgUAAgNgRgAgRgkQgIANAAAXIAAABQABAXAHANQAGAMALAAQAMAAAGgMQAIgNAAgXIAAgBQAAgXgIgMQgGgNgMAAQgLAAgGAMg");
	this.shape_99.setTransform(-25.8,20.075);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AAVBRQgKgOAAgWIAAgEQAAgWAKgOQAKgMAQAAQAQAAAKAMQAKAOAAAWIAAAEQAAAWgKAOQgKANgQAAQgQAAgKgNgAAlAqIAAADQAAAYAKAAQAKAAAAgYIAAgDQAAgZgKABQgKgBAAAZgAhABcIA4hfIAwhYIAaAAIg4BfIgwBYgAhIgFQgLgNABgXIAAgDQgBgWALgOQAKgNAQAAQAQAAAKANQAKAOAAAWIAAADQAAAXgKANQgKANgQAAQgQAAgKgNgAg4gsIAAADQAAAZAKAAQAKAAAAgZIAAgCQAAgZgKAAQgKAAAAAYg");
	this.shape_100.setTransform(164.75,-0.15);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("Ag3BNIARgkQARAMANAAQAKABAGgHQAGgGAAgLQAAgKgHgHQgGgGgJAAQgJABgJAFIgWgNIAFhdIBcAAIAAAnIg7AAIgCAdQAJgDAIAAQAWAAAOAOQAPAOAAAdIAAABQAAAdgRASQgRARgbAAQgcgBgWgQg");
	this.shape_101.setTransform(150.525,0);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgIBdIAAiMIgWAGIgEgnIAmgMIAfAAIAAC5g");
	this.shape_102.setTransform(139.975,-0.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AgzBcIAAi3IBmAAIAAAnIg7AAIAAAiIA1AAIAAAlIg1AAIAAAiIA8AAIAAAng");
	this.shape_103.setTransform(125.8,-0.15);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AgVBdIgwi5IAuAAIAXBwIAZhwIAtAAIgwC5g");
	this.shape_104.setTransform(112.575,-0.1);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AAdBdIgIgiIgqAAIgIAiIgrAAIAxi5IAuAAIAyC5gAAMAYIgMg3IgNA3IAZAAg");
	this.shape_105.setTransform(101.125,-0.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("Ag8BHIAWgjQAWAUAQAAQARgBAAgOQAAgKgVgMQgZgMgKgLQgNgOAAgTIAAgCQAAgYAQgQQAQgPAaAAQAfABAYAUIgWAiQgSgPgQAAQgFgBgEAEQgFADAAAGIAAAAQAAAGAGAFQAEAFAQAJQAWALAJAKQAMAPAAASIAAABQAAAagQAPQgRAPgaAAQghAAgcgXg");
	this.shape_106.setTransform(87.375,-0.15);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgVBcIAAhFIgvhyIAvAAIAWBCIAXhCIAtAAIgvByIAABFg");
	this.shape_107.setTransform(70.075,-0.15);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgwBcIAAi3IAsAAIAACPIA0AAIAAAog");
	this.shape_108.setTransform(60.95,-0.15);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AgUBcIAAiPIgjAAIAAgoIBvAAIAAAoIgiAAIAACPg");
	this.shape_109.setTransform(49,-0.15);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AAZBcIguhbIAABbIgqAAIAAi3IApAAIAsBXIAAhXIAqAAIAAC3g");
	this.shape_110.setTransform(35.55,-0.15);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AAdBdIgIgiIgqAAIgIAiIgrAAIAxi5IAuAAIAyC5gAAMAYIgMg3IgNA3IAZAAg");
	this.shape_111.setTransform(20.825,-0.2);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AgVBcIAAiPIgjAAIAAgoIBxAAIAAAoIgjAAIAACPg");
	this.shape_112.setTransform(10.25,-0.15);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("Ag8BHIAWgjQAWAUAQAAQARgBAAgOQAAgKgVgMQgZgMgKgLQgNgOAAgTIAAgCQAAgYAQgQQAQgPAaAAQAfABAYAUIgWAiQgSgPgQAAQgFgBgEAEQgFADAAAGIAAAAQAAAGAGAFQAEAFAQAJQAWALAJAKQAMAPAAASIAAABQAAAagQAPQgRAPgaAAQghAAgcgXg");
	this.shape_113.setTransform(-2.225,-0.15);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AAZBcIguhbIAABbIgqAAIAAi3IApAAIAsBXIAAhXIAqAAIAAC3g");
	this.shape_114.setTransform(-15.45,-0.15);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AgVBcIAAi3IArAAIAAC3g");
	this.shape_115.setTransform(-26.2,-0.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.type, new cjs.Rectangle(-36.6,-18.1,217.5,79.7), null);


(lib.Find_a_Store_CTA_Dollar_General_2022_Sq_Yellow_RGBai = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Find_a_Store_CTA_Dollar_General_2022_Sq_Yellow_RGB_ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AByASQgHgHAAgLQAAgJAIgIQAHgHALAAQALAAAIAHQAHAHAAAKIAAAAQAAALgHAHQgIAHgLAAQgLAAgIgHgAB6gKQgEAEAAAGIAAAAQAAAGAEAFQAFAEAGAAQAHAAAEgEQAEgEAAgHQAAgFgEgFQgEgEgHAAQgGAAgFAEgAAPARIAGgHQAIAGAHAAQAHAAAAgFIAAAAQAAgEgKgCQgIgCgDgDQgFgDAAgGQAAgHAFgEQAFgEAHAAQAKAAAIAGIgFAIQgIgFgFAAQgGAAAAAFQAAADAKADQAQAEAAAKIAAAAQAAAPgSAAQgNAAgIgIgADeAZIAAgxIAlAAIAAAKIgaAAIAAAKIAXAAIAAAJIgXAAIAAAKIAaAAIAAAKgADIAZIgLgQIgIAAIAAAQIgLAAIAAgxIAWAAQAJAAAGAFQAEAFAAAHQAAAKgLAEIAMASgAC1AAIALAAQAIAAAAgHQAAgHgJAAIgKAAgABMAZIAAgnIgPAAIAAgKIAoAAIAAAKIgPAAIAAAngAgTAZIgEgLIgVAAIgFALIgLAAIAVgxIAKAAIAVAxgAgoAEIANAAIgHgPgAiCAZIAAgxIATAAQAMAAAHAHQAHAHAAAKIAAAAQAAALgHAHQgHAHgMAAgAh3APIAIAAQAHAAAEgEQAEgEAAgHQAAgFgEgFQgEgEgHAAIgIAAgAiYAZIgYgfIAAAfIgLAAIAAgxIAKAAIAXAeIAAgeIALAAIAAAxgAjTAZIAAgxIALAAIAAAxgAkCAZIAAgxIAlAAIAAAKIgbAAIAAALIAYAAIAAAJIgYAAIAAATg");
	this.shape.setTransform(34.975,6.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFF200").s().p("AldBGIAAiLIK7AAIAACLg");
	this.shape_1.setTransform(35,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,70,14);


(lib.Dollar_General_2019_Primary_RGBai = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Dollar_General_2019_Primary_RGB_ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AX9CzQgXgSgSgeIgqhDIgcAAIAAB9IhoAAIAAl4ICNAAQBSAAAjAVQA3AeAABHQAAAsgUAdQgSAdghANIAeAxQAJANAIAFQAIAFALAAQARAAANgJIgGBFQgKAFgQAEQgRAFgOAAQgkAAgYgRgAWOAAIAsAAQAeAAAOgOQANgOAAgfQAAgbgNgOQgOgOgsAAIgeAAgAgMCLQgogyAAhYQAAhdAwgzQAvg0BWAAQBAAAAnAeQAoAeAMA5IhtATQgGgdgLgNQgNgOgWAAQgeAAgRAdQgSAeAAA1QAAB3BWAAQAYAAAUgJIAAg0IgoAAIAAg7ICPAAIAADBIg+AAIgMgTQgSAMgaAHQgbAHgbAAQhYAAgrg5gAldCzQgVgQgUggIgqhDIgcAAIAAB9IhoAAIAAl4ICNAAQBRAAAkAVQA4AfAABGQAAAsgUAdQgSAdghANIAeAxQAIANAIAFQAIAFAMAAQARAAANgJIgHBFQgKAFgPAEQgRAFgOAAQglAAgYgRgAnMAAIAtAAQAeAAAOgOQANgOAAgfQAAgbgOgOQgOgOgsAAIgeAAgA9mCNQgtg0AAhYQAAhYAtg1QAvg3BTAAQBUAAAvA3QAtA1AABYQAABYgtA0QgvA3hUAAQhTAAgvg3gA8kABQAABzBAAAQAhAAAQgbQAQgcAAg8QAAh0hBAAQhAAAAAB0gEAgeAC9IAAl4IBoAAIAAEuICeAAIgEBKgAeWC9IgWhFIh+AAIgVBFIhlAAIBjkvIAUhJIB9AAICHF4gAcwgoIgbBaIBTAAIgdhZQgOgsAAgOIgBAAQgCAUgKAlgAP3C9IAAl4ID9AAIAABJIiUAAIAABMIB5AAIAABIIh5AAIAABRICiAAIgFBKgAN/C9IiZi1QgLgLgFgNIAADNIhVAAIAAl4IA/AAICaC1QALALAGAOIAAjOIBWAAIAAF4gAFSC9IAAl4ID9AAIAABJIiUAAIAABMIB5AAIAABIIh5AAIAABRICiAAIgFBKgArAC9IgXhFIh+AAIgUBFIhmAAIBjkvIAVhJIB8AAICIF4gAsmgoIgbBaIBTAAIgdhZQgOgrAAgPIgCAAQAAAQgLApgAzkC9IAAl4IBoAAIAAEuICfAAIgFBKgA4MC9IAAl4IBpAAIAAEuICeAAIgFBKgEgj9AC9IAAkvIgmAAIAAhJICZAAQByAAAyAlQA6AsAABuQAABlg8AtQg0AnhjAAgEgiVAB0IAgAAQA3AAAUggQAQgZAAg9QAAhDgagYQgWgVg0AAIgXAAgEAi4gB5QgLgMAAgQQAAgQALgLQALgLAQAAIAAAAQAQAAALALQALALAAAQQAAAQgLAMQgLALgQAAQgQAAgLgLgEAi9gCsQgJAKAAANQAAAOAJAJQAJAKANAAQANAAAJgKQAJgJAAgOQAAgNgJgKQgJgKgNAAIAAAAQgNAAgJAKgEAjdgB+QgCgCgBgKQgCgHgHAAIgFAAIAAATIgHAAIAAgsIAMAAQAJAAAFADQADADAAAGQAAAIgIACIAAABQAGABABAJQABAIACADgEAjMgClIAAAPIAFAAQAKAAAAgIQAAgHgKAAg");
	this.shape.setTransform(261.625,46.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFF200").s().p("EAnHAHPQzshLzbAAQzdAAzpBLIgHAAQgtABgfgfQgfggAAgtIAArIQAAgtAfgfQAfgfAtAAIAHAAQTiBMTkgBQTkABTjhMIAHAAQAsAAAgAfQAeAfAAAtIAALIQAAAugeAfQgfAfgtgBg");
	this.shape_1.setTransform(261.65,46.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,523.3,92.7);


(lib.cards2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Xbox_Game_Pass_Ultimate_1mo_M6NS_14_99_043021_RGB();
	this.instance.setTransform(16,0,0.0274,0.0274);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cards2, new cjs.Rectangle(16,0,29.799999999999997,42.1), null);


(lib.cards1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Xbox_Game_Pass_Ultimate_3mo_M6NS_44_99_043021_RGB();
	this.instance.setTransform(33,0,0.0276,0.0276);

	this.instance_1 = new lib.Xbox_Gift_Card_M6NS_50_052119_RGB();
	this.instance_1.setTransform(3,0,0.0271,0.0271);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cards1, new cjs.Rectangle(3,0,60,42.4), null);


(lib.Button1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(51,255,0,0.447)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.Button1 = new lib.Button1();
	this.Button1.name = "Button1";
	this.Button1.setTransform(0,0,1,1,0,0,0,150,125);
	new cjs.ButtonHelper(this.Button1, 0, 1, 2, false, new lib.Button1(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.1,1,1).p("AAATTMAAAgml");
	this.shape.setTransform(-150,-0.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.Button1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-151,-125,301,250), null);


(lib.Find_A_Store_Button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Find_a_Store_CTA_Dollar_General_2022_Sq_Yellow_RGBai("synched",0);
	this.instance.setTransform(63.2,12.6,1.8,1.8,0,0,0,35.1,7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Find_A_Store_Button, new cjs.Rectangle(0,0,126,25.2), null);


(lib.DG_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Dollar_General_2019_Primary_RGBai("synched",0);
	this.instance.setTransform(71.1,12.55,0.2717,0.2713,0,0,0,261.6,46.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.DG_Logo, new cjs.Rectangle(0,0,142.2,25.2), null);


(lib.Black_Swoosh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Vertical_Stretch_Shape_Black_RGBai("synched",0);
	this.instance.setTransform(122.25,89.95,0.4749,0.475,0,0,0,257.4,189.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Black_Swoosh, new cjs.Rectangle(0,0,244.5,180), null);


// stage content:
(lib._114501_DG_Xbox_Campaign_OFFSITE_Web_Banner_728x90_v1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,139];
	// timeline functions:
	this.frame_0 = function() {
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.movieClip_1.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open("http://dollargeneral.com", "_blank");
		}
		
		if(!this.loopsPlayed) {
			this.loopsPlayed = 0;
		}
	}
	this.frame_139 = function() {
		this.loopsPlayed++; console.log(this.loopsPlayed);
		
		if (this.loopsPlayed >= 2) {
			this.stop();	
		} else {
			this.gotoAndPlay(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(139).call(this.frame_139).wait(1));

	// btn
	this.movieClip_1 = new lib.Symbol1();
	this.movieClip_1.name = "movieClip_1";
	this.movieClip_1.setTransform(364,45.1,2.4266,0.36,0,0,0,0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.movieClip_1).wait(140));

	// card2
	this.instance = new lib.cards2();
	this.instance.setTransform(38.4,-90.2,1.9349,1.9349,0,0,0,1.4,-0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(67).to({_off:false},0).to({y:3.3},8).wait(65));

	// card1
	this.instance_1 = new lib.cards1();
	this.instance_1.setTransform(97.15,-46.25,1.9583,1.9583,0,0,0,32.3,20.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10).to({_off:false},0).to({y:44.95},8).wait(49).to({y:135.7},8).to({_off:true},1).wait(64));

	// type1
	this.instance_2 = new lib.type();
	this.instance_2.setTransform(322.3,48.4,1.1358,1.1358,0,0,0,65.3,26.3);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},10).wait(130));

	// CTA_button
	this.instance_3 = new lib.Find_A_Store_Button();
	this.instance_3.setTransform(826.25,62.65,1,1,0,0,0,63,12.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:610.6,y:62.35},10).wait(130));

	// DG_logo
	this.instance_4 = new lib.DG_Logo();
	this.instance_4.setTransform(827.55,27.1,1,1,0,0,0,71.1,12.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:611.9,y:26.8},10).wait(130));

	// black_swoosh
	this.instance_5 = new lib.Black_Swoosh();
	this.instance_5.setTransform(628.9,45,1,1,0,0,0,122.2,90);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(140));

	// snowflakes
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAbDIQgEgCABgEIANgnIgJgZIgKAcQgCAFgEgCQgFgCACgEIANgoIgmhoIgFABIgGArIAQAbQADACgEADQgDABgCgDIgMgTIgDAVIAQAaQACADgDACQgEACgBgDIgLgTIgCAMQgBAEgDgBQgEAAABgEIACgNIgRAPQgDADgDgDQgCgDADgDIAXgVIADgSIgQAOQgDADgCgDQgDgCADgDIAXgVIAGgsIgEgBIhGBWIAAAqQAAAFgFAAQgFAAAAgFIAAgeIgSAWIABAoQAAAFgFAAQgEAAgBgFIAAgcIgKALQgDAEgEgDQgDgDADgEIALgNIgeAGQgFABgBgFQgBgFAFgBIApgIIAPgTIgbAGQgFABgBgFQgBgFAFgBIAngIIBIhYIgDgCIgrAOIgPAaQgCADgDgBQgEgDADgCIAKgTIgRAGIgQAcQgCADgDgCQgDgCACgDIALgUIgMAFQgBAAgBAAQAAABgBgBQgBAAAAgBQAAAAgBgBQgBgDADgCIALgEIgUgHQgEgCABgDQACgEADACIAdAKIAUgHIgWgIQgEgBACgDQABgBAAAAQAAgBABAAQABAAAAAAQABAAABAAIAeAKIAqgOIgBgEIhBgLIAbgFIAoAHIABgEIgKgIIAKgBIAFADIADgCIAAgDIAJgBIAFgBIAAAAIAHgBIAAADIAEABIAFgGIAOgCIgLAOIABAEIApgQIAFgIIAJgCIgDAGIARgHIABgCIAbgEQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgCACIgLAEIAUAHQAFABgCAEQAAABgBABQAAAAgBABQAAAAgBAAQgBAAgBgBIgdgJIgTAHIAVAHQAEACgCADQAAABAAABQgBAAAAABQgBAAAAAAQgBAAgBgBIgegKIgoAQIAAAEIBvARIAjgUQAEgDADAEQACAEgEADIgZAOIAaAEIAigTQAFgDACAFQACAEgEACIgYAOIAQACQAFABgBAFQgBAFgEgBIgQgDIASAVQADAFgDACQgDAEgEgEIgbgeIgagEIAUAWQADADgEAEQgEADgDgEIgbgfIhugRIgCAEIAhAbIAggBQADAAAAAEQAAABAAABQAAAAAAABQgBAAgBABQAAAAgBAAIgXAAIAQANIAfAAQAEAAAAAEQAAABAAAAQgBABAAAAQAAABgBAAQgBAAgBAAIgWABIAJAHQADACgCADQgCADgDgCIgLgJIAFAXQABAEgEAAQgEABgBgEIgGgfIgOgMIAEAVQABAEgEABQgDABgBgEIgGgeIghgcIgDADIAmBnIAlAVQAEACgCAFQgDAEgEgCIgagPIAJAZIAlAVQAEADgCADQgCAFgFgDIgagPIAGAQQACAFgFABQgEACgCgFIgGgPIgKAcIgCADIgCABIgCgBgAjEgHIAGgBIgCABIgCAAIgCAAgAAxhqQAIgCACgJQADgFgCgFIAAgjQAAgBAAAAQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQAFAAAAAFIABAeIARgVIgBgqQAAgFAFAAQAFAAAAAFIAAAeIAKgNQAEgDADADQAEACgDAFIgKAMIAdgGQAFgBABAFQABAFgFABIgpAIIgRAVIAdgGQAFgBABAFQABAFgFABIgpAIIgOASQAAgGgEgEg");
	this.shape.setTransform(508.2419,7.0404,1.6674,1.6674,9.7154);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhVCIIAMgUIgNAEQgBABAAAAQgBAAgBAAQAAgBgBAAQAAgBAAgBQgCgDAEgCIALgEIgVgHQgDgBABgEQACgDADABIAdAKIATgHIgVgHQgEgBACgEQAAgBAAgBQABAAAAAAQABgBABAAQAAAAABABIAeAKIApgPIAAgEIhugRIgkAVQgFACgCgEQgCgFAEgBIAagQIgbgEIgjAVQgDADgDgFQgCgEADgDIAZgOIgQgDQgEgBAAgEQABgFAFABIAQADIgTgWQgEgEAEgDQAEgDADADIAbAfIAaAEIgUgXQgDgDAEgEQADgDAEAEIAbAgIBuARIACgDIgigcIggABQgEAAAAgEQAAgBAAAAQABgBAAgBQABAAAAAAQABAAABAAIAWgBIgQgNIgfABQgDAAgBgEQAAgDAEgBIAWAAIgJgHQgEgBADgDQACgDADACIALAHIgFgVQgBgEAEgBQADgBABAEIAHAeIAOAMIgEgVQgBgDAEgBQADgBABAEIAHAdIAiAcIAEgDIgohoIgjgUQgEgDACgEQACgEAFACIAZAOIgJgWIglgVQgEgDADgEQABgEAFACIAaAPIgGgQIAAgEQABAAAAgBQAAAAABgBQAAAAAAAAQABAAAAAAQAFgCABAEIAGAOIAJgbQABgEAFABQAFACgCAFIgNAmIAKAaIAKgdQACgEAEABQAEACgBAEIgNAoIAnBnIAEAAIAIgsIgQgZQgBgDADgCQADgCACADIALATIADgSIgQgcQgCgCADgDQADgCACADIAMAUIACgNQAAgEAEABQAEAAgBAEIgCAMIARgOQADgDACADQACADgCACIgYAUIgDAVIARgPQADgCACACQADADgDADIgYATIgIArIAEACIBHhWIgBgqQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAFAAAAAFIAAAeIARgVIAAgpQAAgFAEAAQAFAAAAAFIABAdIAKgMQAEgEADADQADADgCAEIgLANIAegGQAFgBABAFQABAEgFABIgpAJIgRAVIAdgGQAFgBABAFQABAEgFABIgpAJIhGBVIACADIApgPIAPgbQADgEACADQADABgBAEIgLASIARgGIAQgcQACgDADACQADABgCAEIgLAUIAMgFQAEgBABADQABAAAAABQAAAAAAAAQAAABAAAAQAAAAgBABIgCACIgKAEIAPAFIgLAEIgPgFIgUAIIAQAFIgKAEIgRgFIgoAPIABAFIAPACIgRAHIghANIgBAAIgBABIgSAIIALgPIgCgEIgqAQIgNAWIgJADQgBAAAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBIALgSIgRAGIgOAXIgJAEQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAg");
	this.shape_1.setTransform(251.3969,71.5961,1.9368,1.9368,22.2131);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAgCcIAAgCIgGgfIgOgMIAEAVQABAEgEABQgEABgBgEIgFgeIghgcIgEADIAdBNIgKAAIgchKIgEABIgGArIAQAbQAAAAAAAAQABABAAAAQAAAAAAABQAAAAgBABIgHAAIgLgTIgDATIgIAAIABgBIACgSIgQAOQgDADgCgDQgCgCACgDIAXgVIAGgsIgDgBIg+BMIgNAAIBDhTIgCgDIgrAPIgQAaQgBADgEgBQgDgDACgCIALgTIgRAGIgQAcQgCADgDgCQgEgCACgDIAMgUIgNAFQgBAAAAAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQgCgDAEgCIALgEIgPgFIAAgBIAAgBIAAgBIAAAAIAAgBIAAgBIAAgBIAAAAIAAgBIAAgBIAaAJIATgHIgVgIQgEgBACgEQAAgBAAAAQABgBAAAAQABAAABAAQAAAAABAAIAeALIAqgPIAAgEIhigQIAAAAIAAgBIAAgBIAAgBIAAgBIAAgBIAAgBIAAgBIAAAAIAAgBIAAgBIBjAQIACgEIgjgbIggABQgEAAAAgEQAAgBAAgBQABgBAAAAQAAAAABgBQABAAABAAIAWgBIgQgLIgfAAQgDAAgBgDQAAgDAEgBIAWgBIgJgHQgEgCADgDQACgDADACIALAJIgFgXQgBgDAEgBQADgBABAEIAHAfIAOAKIgEgUQgBgDAEgBQADgBABADIAHAdIAjAcIAEgCIgphpIgjgUQgEgDACgDQACgFAFADIAZAOIgJgXIglgUQgEgDADgEQABgEAFACIAaAPIgGgRIAAgDQAAgBABAAQAAgBAAAAQABAAAAgBQABAAAAAAQAFgBABAEIAGAOIAJgbQABgEAFABQAFACgCAEIgNAmIAKAaIAKgcQACgFAEACQAFACgCAEIgNAnIAoBoIAEgBIAIgqIgQgbQgBgDADgCQADgBACACIALATIADgSIgQgbQgCgDADgDQADgBACADIAMAUIACgNQAAgEAEABQAEAAgBAEIgCALIARgOQADgCACACQACAEgCACIgYAUIgDAUIARgOQADgDACADQADACgDADIgYAVIgIAqIAEABIBGhVIgBgqQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAAAABAAQAFAAAAAFIAAAeIARgVIAAgqQAAgFAEAAQAFAAAAAFIABAeIAKgNQAEgDADADQADACgCAFIgLAMIAegGQAFgBABAFQABAFgFABIgpAIIgRAVIAdgGQAFgBABAFQABAFgFABIgpAIIhFBVIACAEIAogQIAPgbQADgDACACQADACgBADIgLATIARgHIAQgaQACgEADACQADACgCADIgLATIAMgFQAEgBABAEQAAAAABAAQAAAAAAABQAAAAAAAAQgBABAAAAIgCACIgKAEIAUAHQAEABgCAEQAAABAAABQgBAAAAAAQgBABgBAAQAAgBgBAAIgdgJIgUAHIAWAHQAEACgCADQgBABAAABQAAAAgBABQgBAAAAAAQgBAAgBgBIgegKIgnAQIABAEIBtASIAjgVQAFgDACAEQADAEgEADIgaAPIAaAEIAjgUQAEgDADAFQACAEgEACIgYAPIAQACQAFABgBAFQgBAFgFgBIgQgDIATAVQADAFgEACQgDAEgEgEIgageIgagEIATAWQADADgDAEQgEADgDgEIgcgfIhtgSIgCAEIAhAcIAfgBQAEAAAAAEQAAABgBABQAAAAAAABQgBAAAAAAQgBABgBAAIgWAAIAQANIAeAAQAEAAAAAEQAAAAAAABQAAABgBAAQAAABgBAAQAAAAgBAAIgWABIAJAHQACACgCADQgCADgDgCIgKgJIAEAXIAAADIgHAAg");
	this.shape_2.setTransform(41.8647,52.3175,2.4496,2.4496);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(140));

	// yellow_background
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFF200").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_3.setTransform(364.05,45.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(140));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(363.9,-44.2,534.8000000000001,222.2);
// library properties:
lib.properties = {
	id: '986D694495114666B2B736204257C3A4',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/114501_DG_Xbox_Campaign_OFFSITE_Web_Banner_728x90_v1_atlas_1.png", id:"114501_DG_Xbox_Campaign_OFFSITE_Web_Banner_728x90_v1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['986D694495114666B2B736204257C3A4'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;